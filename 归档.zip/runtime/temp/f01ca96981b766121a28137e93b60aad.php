<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"/Users/zhangchaolin/Sites/public/../application/index/view/index/more.html";i:1550745971;}*/ ?>
<?php foreach($list as $l): ?>
<li class="item"><a target="_blank" href="/detail/<?php echo $current; ?>/<?php echo $l['id']; ?>"><?php echo $l['title']; ?></a></li>
<?php endforeach; if($hasMore): ?>
<li class="item more" data-index="10" data-current="<?php echo $current; ?>"><a href="javascript:void(0);">查看更多</a></li>
<?php endif; ?>