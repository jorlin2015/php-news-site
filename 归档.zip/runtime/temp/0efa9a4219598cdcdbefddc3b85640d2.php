<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"/Users/zhangchaolin/Sites/public/../application/index/view/history/History.html";i:1554105798;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>聊天室</title>
    <link rel="stylesheet" type="text/css" href="/static/css/common.css" />
    <link rel="stylesheet" type="text/css" href="/static/css/index.css" />
    <link rel="stylesheet" type="text/css" href="/static/css/pager.css" />
    <link rel="stylesheet" type="text/css" href="/static/css/history.css" />
</head>
<body data-id="<?php echo $user['user_id']; ?>" data-name="<?php echo $user['user_alias']; ?>" class="msg-history">
    <div class="banner-container">
        <span class="welcome">欢迎<?php echo $user['user_alias']; ?></span><a href="/logout" class="logout">退出</a>
    </div>
    <div class="im-container">
        <div class="msg-container">
            <div class="msg-content">
                <div class="msg-content-scroll">
                </div>
            </div>
        </div>
        <div class="msg-pager">
        </div>
    </div>
    <script type="text/javascript">
        var data = {};
        data.id = '<?php echo $id; ?>';
        data.type = '<?php echo $type; ?>';
    </script>
    <script type="text/javascript" src="/static/js/jquery.js"></script>
    <script type="text/javascript" src="/static/js/date.js"></script>
    <script type="text/javascript" src="/static/js/chat.js"></script>
    <script type="text/javascript" src="/static/js/pager.js"></script>
    <script type="text/javascript" src="/static/js/history.js"></script>
</body>
</html>