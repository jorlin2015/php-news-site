<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"/Users/zhangchaolin/Sites/public/../application/index/view/login/login.html";i:1553502315;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>登录-聊天室</title>
    <link rel="stylesheet" type="text/css" href="/static/css/common.css" />
    <link rel="stylesheet" type="text/css" href="/static/css/login.css" />
<body>
    <form action="/login" method="post" class="login-wrap" name="loginForm">
        <?php if(!(empty($msg) || (($msg instanceof \think\Collection || $msg instanceof \think\Paginator ) && $msg->isEmpty()))): ?><p class="error-wrap"><?php echo $msg; ?></p><?php endif; ?>       
        <p><label><span>账号:</span><input type="text" name="username" required="required" placeholder="请输入账号" /></label></p>
        <p><label><span>密码:</span><input type="password" name="password" required="required" placeholder="请输入密码" /></label></p>
        <p><label><input type="checkbox" name="remember" />5天内自动登录</label></p>
        <p class="btn-wrap">
            <input type="submit" value="登录" class="btn-login"/>
            <a href="/register" class="btn-register">注册</a>
        </p>
    </form>
</body>
</html>