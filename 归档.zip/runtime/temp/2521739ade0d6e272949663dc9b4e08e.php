<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"/Users/zhangchaolin/Sites/public/../application/index/view/index/index.html";i:1554204778;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>聊天室</title>
    <link rel="stylesheet" type="text/css" href="/static/css/common.css" />
    <link rel="stylesheet" type="text/css" href="/static/css/index.css" />
</head>
<body data-id="<?php echo $user['user_id']; ?>" data-name="<?php echo $user['user_alias']; ?>">
    <div class="banner-container">
        <span class="welcome">欢迎<?php echo $user['user_alias']; ?></span><a href="/logout" class="logout">退出</a>
    </div>
    <div class="im-container">
        <ul class="contacts-container">
        </ul>
        <div class="msg-container">
            <div class="msg-title">
            </div>
            <div class="msg-content">
                <div class="msg-content-scroll">
                </div>
            </div>
            <div class="msg-send-wrap">
                <textarea class="msg-send-content" placeholder="Alt+Enter发送消息"></textarea>
                <div class="msg-btn-wrap">
                    <a class="msg-send-btn" href="javascript:void(0)">发送</a>
                </div>
            </div>
        </div>
        <ul class="room-contacts-container">
            
        </ul>
    </div>
    <script type="text/javascript" src="/static/js/jquery.js"></script>
    <script type="text/javascript" src="/static/js/date.js"></script>
    <script type="text/javascript" src="/static/js/index.js"></script>
    <script type="text/javascript" src="/static/js/chat.js"></script>
</body>
</html>