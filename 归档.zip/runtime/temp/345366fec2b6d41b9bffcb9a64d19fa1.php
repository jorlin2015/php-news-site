<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:76:"/Users/zhangchaolin/Sites/public/../application/index/view/index/detail.html";i:1550746109;s:65:"/Users/zhangchaolin/Sites/application/index/view/common/menu.html";i:1550745971;s:67:"/Users/zhangchaolin/Sites/application/index/view/common/footer.html";i:1550745971;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $detail['title']; ?>--今日快报</title>
    <link rel="stylesheet" type="text/css" href="/static/css/common.css">   
</head> 
<body>
    <div class="header">
    <ul class="nav">
        <?php foreach($category as $c): ?>
        <li class="item <?php if($current == $c['code']): ?> current <?php endif; ?>"><a href="/index/<?php echo $c['code']; ?>"><?php echo $c['name']; ?></a></li>
        <?php endforeach; if($isLogin): ?>
        <li class="item logout"><a href="/logout">退出</a></li>
        <?php else: ?>
        <li class="item logout"><a href="/login">登录</a></li>
        <?php endif; ?>
    </ul>
</div>
    <div class="detail">
        <div class="wrap">
            <?php if($isLogin): ?>
            <div class="left">
            <?php endif; ?>
                <h1><?php echo $detail['title']; ?></h1>
                <?php if(empty($detail['sub_title']) || (($detail['sub_title'] instanceof \think\Collection || $detail['sub_title'] instanceof \think\Paginator ) && $detail['sub_title']->isEmpty())): ?>
                <h2 class="sub-title"><?php echo $detail['sub_title']; ?></h2>
                <?php endif; ?>
                <h3 class="info">
                    <span class="author">作者:<?php echo $detail['author']; ?></span>
                    <span class="origin">来源:<?php echo $detail['origin']; ?></span>
                    <span class="time">时间:<?php echo $detail['create_time']; ?></span>
                    <span class="label">标签:<?php foreach($labels as $l): ?> <?php echo $l['name']; ?>&nbsp;<?php endforeach; ?></span>
                </h3>
                <section><?php echo $detail['content']; ?></section>
            <?php if($isLogin): ?>
            </div>
            <div class="right">
                <h2>猜你喜欢</h2>
                <ul>
                    <?php foreach($favors as $f): ?>
                    <li class="item"><a target="_blank" href="/detail/111/<?php echo $f['id']; ?>"><?php echo $f['title']; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
        <div class="comment-wrap">
        <?php if($isLogin): if(empty($comments) || (($comments instanceof \think\Collection || $comments instanceof \think\Paginator ) && $comments->isEmpty())): ?>
                <span class="center">还没有评论</span>
            <?php else: ?>
                <ul class="comments">
                <?php foreach($comments as $c): ?>
                    <li><?php echo $c['content']; ?></li>
                <?php endforeach; ?>
                </ul>
            <?php endif; else: ?>
            <a href="/login">登录</a>后查看评论
        <?php endif; ?>
        </div>
    </div>
    <div class="footer">
	<footer>这是页脚</footer>
</div>
</body>
</html>